import { assert, Component, Enum, EventHandler, EventTouch, Node, UITransform, v2, v3, Vec2, Vec3, _decorator } from "cc";

const { ccclass, property, menu } = _decorator;

export enum JoystickCenterType {
    Inside,
    Cross,
    Outside,
}

export enum JoyStickControlType {
    Fixed,
    Touch,
    TouchFade,
}

export enum JoyStickFrozenType {
    None,
    Horizontal,
    Vertical,
}

@ccclass
@menu("UI/JoystickUI")
export default class JoystickUI extends Component {
    @property(UITransform)
    readonly controlPanel: UITransform = null;
    @property(UITransform)
    readonly center: UITransform = null;
    @property({ type: Enum(JoyStickControlType) })
    controlType: JoyStickControlType = JoyStickControlType.Fixed;
    @property({ type: Enum(JoystickCenterType) })
    centerType: JoystickCenterType = JoystickCenterType.Cross;
    @property({ type: Enum(JoyStickFrozenType) })
    frozenType: JoyStickFrozenType = JoyStickFrozenType.None;

    @property(EventHandler)
    readonly joystickEvents: EventHandler[] = [];

    protected transform: UITransform;
    protected positionTemp = v3();

    private _joystickValue: Vec2 = v2();
    public get joystickValue() { return this._joystickValue; }
    public get joystickDistance() {
        let distance = this.controlPanel.width * 0.5;
        switch (this.centerType) {
            case JoystickCenterType.Inside:
                distance -= this.center.width * 0.5;
                break;
            case JoystickCenterType.Cross:
                break; // nothing
            case JoystickCenterType.Outside:
                distance += this.center.width * 0.5;
                break;
        }
        return distance;
    }

    onEnable(): void {
        this.transform = this.node.getComponent(UITransform);
        this.node.on(Node.EventType.TOUCH_START, this.onJoystickStart, this);
        this.node.on(Node.EventType.TOUCH_MOVE, this.onJoystickMoving, this);
        this.node.on(Node.EventType.TOUCH_END, this.onJoystickStop, this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.onJoystickStop, this);
        assert(this.controlPanel.node.parent == this.node);

        if (this.controlType == JoyStickControlType.TouchFade)
            this.controlPanel.node.active = false;
    }

    onDisable(): void {
        this.onJoystickStop();
        this.node.off(Node.EventType.TOUCH_START, this.onJoystickStart, this);
        this.node.off(Node.EventType.TOUCH_MOVE, this.onJoystickMoving, this);
        this.node.off(Node.EventType.TOUCH_END, this.onJoystickStop, this);
        this.node.off(Node.EventType.TOUCH_CANCEL, this.onJoystickStop, this);
    }

    private onJoystickStart(event: EventTouch) {
        let uiPoint = event.getUILocation();
        let position = this.transform.convertToNodeSpaceAR(this.positionTemp.set(uiPoint.x, uiPoint.y, 0), this.positionTemp);

        switch (this.controlType) {
            case JoyStickControlType.Fixed:
                break;
            case JoyStickControlType.TouchFade:
                this.controlPanel.node.active = true;
            case JoyStickControlType.Touch:
                let uiPoint = event.getUILocation();
                this.controlPanel.node.position = position;
                break;
        }
        this.updateJoystickValue(position);
    }

    private onJoystickMoving(event: EventTouch) {
        let uiPoint = event.getUILocation();
        let position = this.transform.convertToNodeSpaceAR(this.positionTemp.set(uiPoint.x, uiPoint.y, 0), this.positionTemp);
        this.updateJoystickValue(position);
    }

    private onJoystickStop() {
        if (this.controlType == JoyStickControlType.TouchFade)
            this.controlPanel.node.active = false;

        this.joystickValue.set(Vec2.ZERO);
        this.updateCenterPosition();
        EventHandler.emitEvents(this.joystickEvents, this.joystickValue);
    }

    private updateJoystickValue(position: Vec3): void {
        let offset = position.subtract(this.controlPanel.node.position);
        offset.z = 0;
        switch (this.frozenType) {
            case JoyStickFrozenType.Horizontal:
                offset.x = 0;
                break;
            case JoyStickFrozenType.Vertical:
                offset.y = 0;
                break;
        }
        this._joystickValue = JoystickUI.calcuateJoystickValue(this.joystickValue.set(offset.x, offset.y), this.joystickDistance);
        this.updateCenterPosition();
        EventHandler.emitEvents(this.joystickEvents, this.joystickValue);
    }

    private updateCenterPosition(): void {
        let position = Vec2.multiplyScalar(new Vec2(), this.joystickValue, this.joystickDistance);
        this.center.node.position = this.positionTemp.set(position.x, position.y, 0);
    }

    private static calcuateJoystickValue(direction: Vec2, joystickDistance: number): Vec2 {
        let touchRadius = direction.length();
        if (touchRadius == 0) return direction;
        return direction.multiplyScalar(Math.min(1, touchRadius / joystickDistance) / touchRadius);
    }
}