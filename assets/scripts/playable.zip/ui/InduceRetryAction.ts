import { Label, _decorator } from "cc";
import { InstallType, playable } from "../core/Playable";
import GameConfigManager from "../gameConfig/GameConfigManager";
import { InduceAction } from "./InduceAction";

const { ccclass, menu } = _decorator;

@ccclass('InduceRetryAction')
@menu("UI/InduceRetryAction")
export class InduceRetryAction extends InduceAction {

    onEnable(): void {
        const retryCount = GameConfigManager.configValue.playAgain;
        if (playable.retryCount >= retryCount) {
            if (mvPlayable?.disable_induce_click) {
                this.node.active = false;
            } else {
                let label = this.getComponentInChildren(Label);
                if (label != null)
                    label.string = this.induceKeyText;
            }
        }
    }

    protected onButtonClicked(): void {
        const retryCount = GameConfigManager.configValue.playAgain;
        if (playable.retryCount < retryCount)
            playable.retryGame();
        else {
            playable.install(InstallType.Induce);
        }
    }
}