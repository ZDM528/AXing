import { Button, Component, Enum, _decorator } from "cc";
import { InstallType, playable } from "../core/Playable";
import GameConfigManager from "../gameConfig/GameConfigManager";

const { ccclass, property, requireComponent, menu, disallowMultiple } = _decorator;

@ccclass('RetryAction')
@requireComponent(Button)
@disallowMultiple
@menu("UI/RetryAction")
export class RetryAction extends Component {

    @property({ tooltip: "当重玩次数为0，自动隐藏本按钮。" })
    readonly autoHide: boolean = false;
    @property({ type: Enum(InstallType) })
    readonly installType: InstallType = InstallType.Induce;

    onLoad(): void {
        const retryCount = GameConfigManager.configValue.playAgain;
        let button = this.getComponent(Button);
        button.node.on(Button.EventType.CLICK, () => {
            if (playable.retryCount < retryCount)
                playable.retryGame();
            else
                playable.install(this.installType);
        });
        if (this.autoHide && playable.retryCount >= retryCount)
            this.node.active = false;
    }
}