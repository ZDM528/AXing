import { Component, view, _decorator } from "cc";
import { EDITOR } from "cc/env";
import HorizontalLayout from "../layout/HorizontalLayout";
import VerticalLayout from "../layout/VerticalLayout";
import { AdaptScreenManager } from "./AdaptScreenManager";

const { ccclass, property, requireComponent, executeInEditMode, disallowMultiple, menu } = _decorator;
@ccclass('AdaptLayout')
@requireComponent(HorizontalLayout)
@requireComponent(VerticalLayout)
@executeInEditMode
@disallowMultiple
@menu("UI/AdaptLayout")
export default class AdaptLayout extends Component {
    onLoad(): void {
        if (EDITOR) {
            view.on('editor-canvas-resize', this.onResizeChanged, this);
            this.onResizeChanged(view.editorCanvasSizeRatio);
        } else {
            AdaptScreenManager.onResizeEvent.addEvent(this.onResizeEvent, this);
            this.onResizeEvent();
        }
    }

    onDestroy(): void {
        if (EDITOR) {
            view.off('editor-canvas-resize', this.onResizeChanged, this);
        } else {
            AdaptScreenManager.onResizeEvent.removeEvent(this.onResizeEvent, this);
        }
    }

    private onResizeChanged(ratio: number): void {
        let hLayout = this.getComponent(HorizontalLayout);
        let vLayout = this.getComponent(VerticalLayout);
        if (ratio > AdaptScreenManager.RATIO_UNIT) { // Landscape
            if (hLayout) hLayout.enabled = true;
            if (vLayout) vLayout.enabled = false;
        } else { // Portrait
            if (hLayout) hLayout.enabled = false;
            if (vLayout) vLayout.enabled = true;
        }
    }

    private onResizeEvent(): void {
        this.onResizeChanged(AdaptScreenManager.canvasSizeRatio);
    }
}