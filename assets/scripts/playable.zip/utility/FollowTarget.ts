
import { _decorator, Component, Node, Vec3, Quat, Enum } from 'cc';
const { ccclass, property, executeInEditMode } = _decorator;

export enum FollowMode {
    /** 像机从当前点位置看向目标，目标旋转时，像机不动，注意：像机不能与目标位置重叠。 */
    LookTarget,
    /** 像机方向会锁定目标的前方，目标旋转时，像机也会跟着旋转 */
    LockForward,
    /** 像机方向会锁定目标的后方，目标旋转时，像机也会跟着旋转 */
    LockFlipForward,
}

@ccclass('FollowTarget')
// @executeInEditMode
export class FollowTarget extends Component {
    @property(Node)
    public target: Node = null;
    @property({ type: Enum(FollowMode) })
    public followMode: FollowMode = FollowMode.LookTarget;
    @property
    public distance: number = 5;
    @property
    public height: number = 5;
    @property
    public smoothTime: number = 0.5;

    private currentVelocity = new Vec3();
    private directionTemplate = new Vec3();
    private upTemplate = new Vec3();

    update(deltaTime: number): void {
        if (this.target == null) return;
        let direction: Vec3;
        switch (this.followMode) {
            case FollowMode.LookTarget:
                direction = Vec3.subtract(this.directionTemplate, this.node.worldPosition, this.target.worldPosition);
                break;
            case FollowMode.LockForward:
                direction = this.directionTemplate.set(this.target.forward);
                break;
            case FollowMode.LockFlipForward:
                let forward = this.target.forward;
                direction = this.directionTemplate.set(-forward.x, -forward.y, -forward.z);
                break;
        }
        direction.y = 0;
        direction = direction.multiplyScalar(this.distance / direction.length());
        let up = Vec3.multiplyScalar(this.upTemplate, this.target.up, this.height);
        let targetPosition = up.add(direction).add(this.target.worldPosition);

        this.node.worldPosition = this.node.worldPosition.smoothDamp(targetPosition, this.smoothTime, this.currentVelocity, Infinity, deltaTime);
        direction = Vec3.subtract(direction, this.node.worldPosition, this.target.position);
        this.node.rotation = Quat.fromViewUp(this.node.rotation, direction.normalize(), this.target.up);
    }
}