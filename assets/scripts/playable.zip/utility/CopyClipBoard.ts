import { rect, sys, VERSION } from "cc";
import { v2 } from "cc";
import { Button, CCString, Component, Label, _decorator, Node, UIOpacity, v3, Vec3, director, view, UITransform, game } from "cc";
import { playable } from "../core/Playable";
import LocalizeManager from "../localize/LocalizeManager";
import { XTween, xtween } from "../xtween/XTween";

const { ccclass, property, requireComponent } = _decorator;
@ccclass("CopyClipBoard")
@requireComponent(Button)
export default class CopyClipBoard extends Component {
    @property(Label)
    readonly promptLabel: Label = null;
    @property
    readonly promptOffsetY: number = 200;
    @property(CCString)
    readonly codeKey: string = "code";

    private startPosition: Vec3 = new Vec3();
    private targetPosition: Vec3 = new Vec3();
    private uitransform: UITransform;

    onEnable(): void {
        // this.node.on(Button.EventType.CLICK, this.copyToClipBoard, this);
        this.promptLabel.node.active = false;
        this.startPosition.set(this.promptLabel.node.position);
        this.targetPosition.set(this.startPosition);
        this.targetPosition.y += this.promptOffsetY;

        this.uitransform = this.node.getComponent(UITransform);

        // IOS 要求点击的同一帧内响应的事件，才能复制。而引擎的事件是帧循环响应的，所以IOS复制失败。
        let pressed: boolean = false;
        game.canvas.addEventListener("touchstart", () => pressed = true);
        game.canvas.addEventListener("touchcancel", () => pressed = false);
        game.canvas.addEventListener("touchend", (event) => {
            if (pressed) pressed = false, this.checkHitNode(event.changedTouches[0]);
        }, { capture: true, passive: true });
        game.canvas.addEventListener("click", (event) => this.checkHitNode(event));
    }

    private checkHitNode(event: { clientX: number, clientY: number }): void {
        const canvas = game.canvas;
        const box = canvas.getBoundingClientRect();
        if (box == null) return;

        const relatedPos = { left: box.x, top: box.y, width: box.width, height: box.height };
        let location = view.convertToLocationInView(event.clientX, event.clientY, relatedPos, null);

        view["_convertPointWithScale"](location);
        let hit = this.uitransform.isHit(location);
        if (hit) this.copyToClipBoard();
    }

    onDisable(): void {
        // this.node.off(Button.EventType.CLICK, this.copyToClipBoard, this);
    }

    public copyToClipBoard(): void {
        let data = LocalizeManager.getCurLocalizeValue(this.codeKey);
        let result = playable.copyToClipBoard(data.value);

        if (result && this.promptLabel != null) {
            XTween.removeTargetTweens(this.promptLabel);
            let uiOpacity = this.promptLabel.getOrAddComponent(UIOpacity);
            uiOpacity.opacity = 255;
            this.promptLabel.node.active = true;
            this.promptLabel.node.position = this.startPosition;
            const duration = 1;
            xtween(this.promptLabel).parallel(
                xtween(this.promptLabel.node).to(duration, { position: this.targetPosition }),
                xtween(uiOpacity).to(duration, { opacity: 0 }, { easing: XTween.Easing.Quintic.In })
            ).call(() => this.promptLabel.node.active = false).start();
        }
    }
}