import { _decorator, Component, Node, Button, Enum } from "cc";
import { playable } from "../core/Playable";

const { ccclass, property } = _decorator;

enum EventType {
    DOWN,
    UP,
    MOVE,
    CLICK,
}

@ccclass('PlayableAction')
export class PlayableAction extends Component {
    @property
    readonly action: number = 0;
    @property({ type: Enum(EventType) })
    readonly eventType: EventType = EventType.CLICK;

    onLoad(): void {
        switch (this.eventType) {
            case EventType.DOWN:
                this.node.once(Node.EventType.TOUCH_START, () => playable.sendAction(this.action));
                break;
            case EventType.UP:
                this.node.once(Node.EventType.TOUCH_END, () => playable.sendAction(this.action));
                break;
            case EventType.MOVE:
                this.node.once(Node.EventType.TOUCH_MOVE, () => playable.sendAction(this.action));
                break;
            case EventType.CLICK:
                this.node.once(Button.EventType.CLICK, () => playable.sendAction(this.action));
                break;
        }
    }
}