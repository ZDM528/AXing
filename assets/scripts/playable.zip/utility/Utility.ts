import { Node } from "cc";
import { XTween, xtween } from "../xtween/XTween";

export default class Utility {
    public static shakeCamera(node: Node, offset: { min: number, max: number } = { min: -0.2, max: 0.20 }, interval: number = 0.02, repeat: number = 4): void {
        let xMinOffset = Math.randomRange(offset.min, offset.max);
        let zMinOffset = Math.randomRange(offset.min, offset.max);
        XTween.repeat(repeat, true, xtween(node).by(interval, { positionX: xMinOffset, positionY: zMinOffset })).start();
    }
}