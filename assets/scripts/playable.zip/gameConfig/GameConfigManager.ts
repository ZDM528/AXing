import { JsonAsset, resources } from "cc";
import { DEBUG } from "cc/env";

export interface IGameConfig<T> {
    /** 可重玩次数 */
    playAgain: number;
    /**
     * 设置调试数据，发布后，该数据不会被修改
     * @param name 
     * @param value 
     */
    setDebugValue<K extends ObjectProperties<T>>(name: K, value: T[K]): void;
}

interface GameConfigJson {
    playAgain: number;
    gameConfig: { [x: string]: { value: any, items?: Array<{ pl_key: string, value: any }> } };
}

export default class GameConfigManager {
    private static _configValue = {} as IGameConfig<any>;
    public static get configValue() { return GameConfigManager._configValue; }

    public static async initialize(filePath: string): Promise<void> {
        let data = await GameConfigManager.loadConfigData(filePath);
        for (let key of Object.keys(data.gameConfig)) {
            let items = data.gameConfig[key].items;
            if (items != null) {
                for (let item of items)
                    GameConfigManager.configValue[item.pl_key] = item.value;
            } else {
                GameConfigManager.configValue[key] = data.gameConfig[key].value;
            }
        }
        GameConfigManager.configValue.playAgain = data.playAgain ?? 0;
        GameConfigManager.configValue.setDebugValue = function (key: PropertyKey, value: any) { if (DEBUG) GameConfigManager.configValue[key] = value; }
        globalThis.gameConfig = GameConfigManager.configValue;
        resources.release(filePath, JsonAsset);
    }

    protected static async loadConfigData(filename: string): Promise<GameConfigJson> {
        return new Promise<any>((resolve, reject) => {
            resources.load(filename, JsonAsset, (error, asset) => {
                if (error != null) return reject(error);
                resolve(asset.json);
            });
        });
    }
}