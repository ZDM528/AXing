import { Camera, Canvas, CCString, Component, instantiate, Node, Prefab, resources, _decorator } from "cc";
import { View } from "../ui/View";
import ActionEvent from "../utility/ActionEvent";
import { playable } from "./Playable";
import { ISystem } from "./RegisterSystem";

const { ccclass, property } = _decorator;

@ccclass('GameManager')
export class GameManager extends Component {
    private static _instance: GameManager;
    public static get instance() { return GameManager._instance; }
    private static readonly systemList: ISystem[] = [];

    @property(Camera)
    readonly mainCamera: Camera = null;
    @property(Canvas)
    readonly canvas: Canvas = null;
    @property(Node)
    readonly uiRoot: Node = null;
    @property
    readonly gameViewPath: string = "prefabs/gameView";
    @property
    readonly endingViewPath: string = "prefabs/endingView";
    @property([CCString])
    readonly preloadAssets: string[] = [];
    @property([CCString])
    readonly preloadDirAssets: string[] = [];
    @property({ tooltip: "重玩援关闭埋点记录" })
    readonly disableRetryActions: boolean = false;

    private _isLoadedComplete: boolean = false;
    public get isLoadedComplete() { return this._isLoadedComplete; }
    public readonly onLoadedCompleteEvent = new ActionEvent();

    private _gameView: View;
    public get gameView() { return this._gameView; }
    private _endingView: View;
    public get endingView() { return this._endingView; }

    __preload(): void {
        GameManager._instance = this;
    }

    public async initialize(): Promise<void> {
        await new Promise<void>(resolve => resources.load([this.endingViewPath, ...this.preloadAssets], () => resolve()));
        if (this.preloadDirAssets.length > 0)
            await new Promise<void>(resolve => resources.load(this.preloadDirAssets, () => resolve()));

        await this.createGameView();

        this._endingView = await this.createView<View>(this.endingViewPath);
        this.endingView.node.setParent(this.uiRoot, false);
        this.endingView.node.active = false;

        this._isLoadedComplete = true;
        this.onLoadedCompleteEvent.dispatchAction();
        if (this.disableRetryActions)
            playable.retryEvent.addEventOnce(() => playable.enableAction = false);
    }

    public async createGameView(): Promise<void> {
        this._gameView = await this.createView<View>(this.gameViewPath);
        this.gameView.node.setParent(this.uiRoot, false);
        return this.gameView.intialize();
    }

    public hideGameView(): void {
        this.gameView.node.active = false;
    }

    public getGameView<T extends View>(): T {
        return this.gameView as T;
    }

    public async createEndingView<T extends View>(...params: Parameters<T["intialize"]>): Promise<void> {
        // this._endingView = await this.createView<View>(this.endingViewPath);
        // this.endingView.node.setParent(this.uiRoot, false);
        this.endingView.intialize(...params);
        this.endingView.node.active = true;

    }

    public hideEndingView(): void {
        this.endingView.node.active = false;
    }

    public getEndingView<T extends View>(): T {
        return this.endingView as T;
    }

    public async createView<T extends View>(path: string): Promise<View> {
        let prefab = await new Promise<Prefab>(resolve => resources.load(path, Prefab, (error, data) => resolve(data)));
        let viewNode = instantiate(prefab);
        return viewNode.getComponent(View);
    }

    public static registerSystem(system: ISystem): void {
        GameManager.systemList.push(system);
    }
}