/** 角色阵营，用来表示盟友和敌人的关系 */
export enum CharacterCamp {
    Camp1,
    Camp2,
    Camp3,
    Camp4,
    Camp5,
    Camp6,
    Camp7,
    Camp8,
    Camp9,
}