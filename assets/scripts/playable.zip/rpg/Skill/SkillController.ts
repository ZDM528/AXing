import Character from "../Character";
import CharacterComponent from "../CharacterComponent";
import Skill from "./Skill";

export default class SkillController extends CharacterComponent<Character> {
    private _skillableCount: number = 0;
    /** 是否可使用技能，普攻 */
    public get skillable() { return this._skillableCount >= 0; }
    private _skillList: Skill[];
    /** 技能列表（包括普通攻击） */
    public get skillList() { return this._skillList; }
    /** 普通攻击 */
    public get attackSkill() { return this._skillList[0]; }
    /** 第一个技能 */
    public get skill() { return this._skillList[1]; }

    public initialize(skills: Skill[]): void {
        this._skillList = skills;
        this._skillableCount = 0;
        this.character.diedEvent.addEvent(this.onDied, this);
        for (let skill of skills)
            skill.initialize(this.character, this);
    }

    /** 开启使用技能 */
    public enableSkill(): void {
        this._skillableCount++;
    }

    /** 关闭使用技能 */
    public disableSkill(): void {
        this._skillableCount--;
    }

    protected onDied(): void {
        for (let skill of this.skillList)
            skill.Complete(false);
        this.disableSkill();
    }
}