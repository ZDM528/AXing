/** 角色默认的动画类型 */

export enum CharacterAnimationType {
    Bron,
    Sleep,
    Idle,
    Walk,
    Run,
    Attack,
    Skill,
    Die
}