import { Vector2 } from "./Vector2";

export class Line {
    public point: Vector2;
    public direction: Vector2;
}