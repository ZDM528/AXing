import { CCInteger } from "cc";
import { _decorator } from "cc";
import { TweenComponent } from "./TweenComponent";
import { XTween, xtween } from "./XTween";

const { ccclass, property } = _decorator;

@ccclass('TweenRotationLoop')
export class TweenRotationLoop extends TweenComponent {
    @property({ type: CCInteger, min: -360, max: 360 })
    readonly angle: number = 360;

    public createTween(): XTween<any> {
        return xtween(this.node).repeatForever(false, xtween(this.node).by(this.duration, { angle: this.angle }));
    }
}