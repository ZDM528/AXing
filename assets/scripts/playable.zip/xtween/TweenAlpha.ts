import { CCInteger, Renderable2D, UIOpacity, _decorator } from "cc";
import { TweenComponent } from "./TweenComponent";
import { XTween, xtween } from "./XTween";

const { ccclass, property } = _decorator;

@ccclass('TweenAlpha')
export class TweenAlpha extends TweenComponent {
    @property({ type: CCInteger, min: 0, max: 255 })
    readonly startOpacity: number = 0;
    @property({ type: CCInteger, min: 0, max: 255 })
    readonly endOpacity: number = 255;

    protected createTween(): XTween<any> {
        let renderable2D = this.node.getComponent(Renderable2D);
        if (renderable2D != null) {
            renderable2D.colorA = this.startOpacity;
            return xtween(renderable2D).to(this.duration, { colorA: this.endOpacity });
        } else {
            let uiopacity = this.node.getOrAddComponent(UIOpacity);
            uiopacity.opacity = this.startOpacity;
            return xtween(uiopacity).to(this.duration, { opacity: this.endOpacity });
        }
    }
}