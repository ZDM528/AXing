import { Component, Vec3, _decorator } from "cc";
import { XTween, xtween } from "./XTween";

const { ccclass, property } = _decorator;

@ccclass('TweenComponent')
export abstract class TweenComponent extends Component {
    @property
    readonly duration: number = 1;
    @property
    readonly delay: number = 1;
    // @property
    // readonly easing: string = "linear";
    @property
    readonly playOnLoad: boolean = true;

    onLoad(): void {
        if (this.playOnLoad) this.execute();
    }

    onEnable(): void {
        if (!this.playOnLoad || !XTween.containTweens(this)) this.execute();
    }

    onDisable(): void {
        if (!this.playOnLoad) XTween.removeTargetTweens(this);
    }

    public execute(): void {
        xtween(this).delay(this.delay).then(this.createTween()).start();
    }

    protected abstract createTween(): XTween<any>;
}