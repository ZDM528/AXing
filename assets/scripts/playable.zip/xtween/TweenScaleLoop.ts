import { Vec3, _decorator } from "cc";
import { TweenComponent } from "./TweenComponent";
import { XTween, xtween } from "./XTween";

const { ccclass, property } = _decorator;

@ccclass('TweenScaleLoop')
export class TweenScaleLoop extends TweenComponent {
    @property
    readonly scale: number = 0.1;

    public createTween(): XTween<any> {
        return xtween(this.node).repeatForever(true,
            xtween(this.node).by(this.duration, { scale: new Vec3(this.scale, this.scale, this.scale) })
        );
    }
}